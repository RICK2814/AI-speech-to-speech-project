"""Frontend package for Streamlit UI."""

"""Backend package for pipelines and orchestration."""
